package com.sely.assistant

import android.app.Notification
import android.content.Context
import android.content.SharedPreferences
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class SelyNotificationListener : NotificationListenerService() {

    companion object {
        // Kept in memory so Sely can actually fire the reply action while this listener is alive.
        var lastReplyAction: Notification.Action? = null
        var lastSender: String? = null
        var lastMessage: String? = null
    }

    private val watchedPackages = setOf("com.whatsapp", "com.google.android.apps.messaging")
    private val maxInboxSize = 20

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in watchedPackages) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return

        lastSender = title
        lastMessage = text
        lastReplyAction = sbn.notification.actions?.firstOrNull { action ->
            action.remoteInputs != null && action.remoteInputs!!.isNotEmpty()
        }

        val prefs: SharedPreferences = getSharedPreferences("sely_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("last_message_sender", title)
            .putString("last_message_text", text)
            .apply()

        appendToInbox(prefs, title, text)
    }

    private fun appendToInbox(prefs: SharedPreferences, sender: String, text: String) {
        val raw = prefs.getString("recent_messages", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val updated = JSONArray()
        // Keep only the most recent (maxInboxSize - 1) existing entries, then add the new one
        val start = maxOf(0, arr.length() - (maxInboxSize - 1))
        for (i in start until arr.length()) updated.put(arr.getJSONObject(i))
        updated.put(JSONObject().apply {
            put("sender", sender)
            put("text", text)
        })
        prefs.edit().putString("recent_messages", updated.toString()).apply()
    }
}
